
#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char** argv) {
    
    double dollar, yen, euro; //hold value of the currencies
    
    double yen_per_dollar, euros_per_dollar; //hold exchanged value
    
    
    // will be using the exchange rates 1 dollar= 98.93 yen or 0.74 euros
    
    yen = 98.93;
    euro = 0.74;
    
    cout << "Enter the amount of dollars you want to exchange into yen or eueros"<< endl;
    
    cin >> dollar;
    
    cout << "you entered: " << endl << dollar << " USD"<<endl;
    
    yen_per_dollar = dollar* yen;
    
    euros_per_dollar = dollar * euro;
    
    cout << dollar << " USD is worth: "<<endl<< yen_per_dollar <<" YEN"<<endl
            << euros_per_dollar<< " EU";
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    return 0;
}

