/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: felix
 *
 * Created on September 10, 2019, 10:58 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    
    double gas; // quantity of gas it can hold
    
    double miles; // hold amount of miles it can drive with full tank of gas
    
    double tank; // full tank
    
    
    
    cout << "How many Gallons of gasoline can your car hold?"<<endl;
    
    cin >> tank; // input gas
    
    cout << "How many miles can your car drive on a full tank of gas?"<<endl;
    cin >> miles;
    
    gas = miles/ tank; // divide full gas tank by maximum range on full tank
    
    
    
    cout << "you car is able to get:"<< gas <<" miles per gallon";
    
    
    

    
    
    

    return 0;
}

