/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: felix
 *
 * Created on September 10, 2019, 2:18 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;





int main(int argc, char** argv) {
    
    float f, c;
    
    
    cout <<"enter temperature in celsius:";
    
    cin >> c;
    
    f = 1.8 * c + 32;
    
    cout << "result in fahrenheit is:";
    
    cout << f;
    
    

    return 0;
}

